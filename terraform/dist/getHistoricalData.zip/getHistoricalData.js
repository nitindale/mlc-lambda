"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const s3 = new aws_sdk_1.default.S3();
const BUCKET_NAME = process.env.BUCKET_NAME;
const handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    const city = event.pathParameters.city;
    if (!city) {
        return {
            statusCode: 400,
            body: JSON.stringify({ error: "City parameter is required." }),
        };
    }
    try {
        const listObjectsResponse = yield s3
            .listObjectsV2({ Bucket: BUCKET_NAME, Prefix: `weather/${city}/` })
            .promise();
        if (!listObjectsResponse.Contents || listObjectsResponse.Contents.length === 0) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: "No historical data found for this city." }),
            };
        }
        const historicalDataPromises = listObjectsResponse.Contents.map((object) => s3
            .getObject({ Bucket: BUCKET_NAME, Key: object.Key })
            .promise()
            .then((data) => JSON.parse(data.Body.toString())));
        const historicalData = yield Promise.all(historicalDataPromises);
        return { statusCode: 200, body: JSON.stringify({ data: historicalData }) };
    }
    catch (error) {
        return { statusCode: 500, body: JSON.stringify({ error: error.message }) };
    }
});
exports.handler = handler;
